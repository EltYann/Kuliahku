# Membuat ikon PNG (huruf K putih di latar indigo) tanpa library tambahan.
import zlib, struct, math
def seg(px, py, x1, y1, x2, y2):
    dx, dy = x2 - x1, y2 - y1
    t = max(0, min(1, ((px - x1) * dx + (py - y1) * dy) / (dx * dx + dy * dy)))
    return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy))
def png(n, path):
    raw = bytearray()
    for y in range(n):
        raw.append(0)
        for x in range(n):
            u, v = x / n, y / n
            k = (0.34 <= u <= 0.43 and 0.29 <= v <= 0.71) or seg(u, v, .43, .50, .64, .29) < .045 or seg(u, v, .46, .47, .65, .71) < .045
            raw += bytes((255, 255, 255) if k else (67, 56, 202))
    ch = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d))
    open(path, 'wb').write(b'\x89PNG\r\n\x1a\n' + ch(b'IHDR', struct.pack('>IIBBBBB', n, n, 8, 2, 0, 0, 0)) + ch(b'IDAT', zlib.compress(bytes(raw))) + ch(b'IEND', b''))
png(192, 'icon-192.png'); png(512, 'icon-512.png')
