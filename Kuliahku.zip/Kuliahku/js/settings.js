// Preferensi kecil (LocalStorage) + halaman Pengaturan. Data kuliah ada di IndexedDB (db.js).
import { h, toast, confirmBox, field } from './ui.js';
import { exportAll, importAll, resetAll } from './db.js';

export const VERSION = '0.1.0';
const KEY = 'kuliahku.prefs';
const DEFAULTS = { name: '', semester: '', theme: 'system', onboarded: false };

export function getPrefs() {
  try { return { ...DEFAULTS, ...JSON.parse(localStorage.getItem(KEY)) }; } catch { return { ...DEFAULTS }; }
}
export function setPrefs(p) {
  try { localStorage.setItem(KEY, JSON.stringify({ ...getPrefs(), ...p })); } catch { toast('Pengaturan tidak bisa disimpan di browser ini.'); }
  applyTheme();
}
export function applyTheme() {
  const t = getPrefs().theme;
  const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

export function renderSettings(root) {
  const p = getPrefs();
  const name = h('input', { value: p.name, maxlength: 30, placeholder: 'Opsional' });
  const sem = h('input', { value: p.semester, maxlength: 10, placeholder: 'Contoh: 3' });
  const save = () => { setPrefs({ name: name.value.trim(), semester: sem.value.trim(), onboarded: true }); toast('Tersimpan'); };
  name.onchange = sem.onchange = save;

  const theme = h('select', { onchange: e => { setPrefs({ theme: e.target.value }); toast('Tema diubah'); } },
    [['system', 'Ikuti sistem'], ['light', 'Terang'], ['dark', 'Gelap']]
      .map(([v, l]) => h('option', { value: v, selected: p.theme === v }, l)));

  const doExport = async () => {
    try {
      const blob = new Blob([JSON.stringify(await exportAll(), null, 2)], { type: 'application/json' });
      const a = h('a', { href: URL.createObjectURL(blob), download: `kuliahku-cadangan-${new Date().toISOString().slice(0, 10)}.json` });
      document.body.append(a); a.click(); a.remove();
      toast('Cadangan diunduh');
    } catch (e) { toast('Gagal ekspor: ' + e.message); }
  };

  const file = h('input', { type: 'file', accept: 'application/json,.json', hidden: true, onchange: async e => {
    const f = e.target.files[0]; e.target.value = '';
    if (!f) return;
    try {
      const json = JSON.parse(await f.text());
      if (!await confirmBox('Impor cadangan?', 'Semua data di HP ini akan DIGANTI dengan isi berkas cadangan.', 'Ya, ganti data')) return;
      await importAll(json);
      toast('Cadangan berhasil diimpor');
      location.hash = '#/';
    } catch (err) { toast(err instanceof SyntaxError ? 'Berkas bukan JSON yang valid.' : err.message); }
  } });

  const doReset = async () => {
    if (!await confirmBox('Hapus semua data?', 'Seluruh data kuliahmu di HP ini akan dihapus permanen. Data tidak tersimpan di cloud, jadi tidak bisa dipulihkan kecuali kamu punya berkas cadangan.', 'Ya, hapus semua')) return;
    try { await resetAll(); localStorage.removeItem(KEY); applyTheme(); toast('Semua data dihapus'); location.hash = '#/'; }
    catch (e) { toast('Gagal menghapus: ' + e.message); }
  };

  root.replaceChildren(
    h('h2', {}, 'Pengaturan'),
    h('div', { class: 'card' }, field('Nama panggilan', name), field('Semester', sem), field('Tema', theme)),
    h('div', { class: 'card' }, h('h3', {}, 'Cadangan data'),
      h('p', { class: 'muted' }, 'Datamu hanya tersimpan di HP ini. Menghapus data browser atau aplikasi bisa menghilangkan data jika belum dicadangkan.'),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: doExport }, 'Ekspor JSON'),
        h('button', { class: 'btn', onclick: () => file.click() }, 'Impor JSON')), file),
    h('div', { class: 'card' }, h('h3', {}, 'Hapus semua data'),
      h('button', { class: 'btn danger', onclick: doReset }, 'Reset seluruh data')),
    h('p', { class: 'muted' }, `KuliahKu v${VERSION} • Bukan sistem akademik resmi kampus. Tanpa akun, tanpa server.`));
}
