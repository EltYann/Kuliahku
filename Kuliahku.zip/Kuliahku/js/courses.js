// Mata Kuliah: tambah, ubah, hapus (CRUD) memakai IndexedDB.
import { h, toast, confirmBox, sheet, empty, field } from './ui.js';
import { getAll, put, remove } from './db.js';

export const COLORS = ['#4338ca', '#0e7490', '#15803d', '#a16207', '#c2410c', '#be123c', '#a21caf', '#475569'];

export async function renderCourses(root) {
  const list = (await getAll('courses')).sort((a, b) => a.name.localeCompare(b.name, 'id'));
  root.replaceChildren(
    h('div', { class: 'head' }, h('h2', {}, 'Mata Kuliah'),
      h('button', { class: 'btn primary', onclick: () => openForm(null, root) }, '+ Tambah')),
    list.length ? list.map(c => card(c, root))
      : empty('Belum ada mata kuliah', 'Ketuk "+ Tambah" untuk memasukkan mata kuliah pertamamu.'));
}

function card(c, root) {
  const meta = [c.code, c.sks + ' SKS', c.lecturer].filter(Boolean).join(' • ');
  return h('div', { class: 'card course', style: `--c:${c.color}` },
    h('div', {}, h('h3', {}, c.name), h('div', { class: 'muted' }, meta), c.note && h('div', { class: 'muted' }, c.note)),
    h('div', { class: 'acts' },
      h('button', { class: 'btn sm', onclick: () => openForm(c, root) }, 'Ubah'),
      h('button', { class: 'btn sm danger', onclick: async () => {
        if (!await confirmBox('Hapus mata kuliah?', `"${c.name}" akan dihapus dari HP ini.`, 'Ya, hapus')) return;
        try { await remove('courses', c.id); toast('Dihapus'); } catch (e) { toast('Gagal menghapus: ' + e.message); }
        renderCourses(root);
      } }, 'Hapus')));
}

function openForm(c, root) {
  let color = c?.color || COLORS[0], close;
  const name = h('input', { value: c?.name ?? '', maxlength: 80, required: true });
  const code = h('input', { value: c?.code ?? '', maxlength: 20 });
  const sks = h('input', { type: 'number', inputmode: 'numeric', min: 1, max: 10, value: c?.sks ?? 2 });
  const lec = h('input', { value: c?.lecturer ?? '', maxlength: 80 });
  const note = h('textarea', { rows: 2, maxlength: 300 }, c?.note ?? '');
  const sws = COLORS.map(col => h('button', { type: 'button', class: 'sw' + (col === color ? ' on' : ''), style: `--c:${col}`, 'aria-label': 'Warna ' + col,
    onclick: e => { color = col; sws.forEach(s => s.classList.remove('on')); e.currentTarget.classList.add('on'); } }));

  const save = async () => {
    const n = name.value.trim(), s = Number(sks.value);
    if (!n) return toast('Nama mata kuliah wajib diisi');
    if (!Number.isInteger(s) || s < 1 || s > 10) return toast('SKS harus bilangan bulat 1–10');
    try {
      await put('courses', { ...c, name: n, code: code.value.trim(), sks: s, lecturer: lec.value.trim(), color, note: note.value.trim() });
      close(); toast('Tersimpan'); renderCourses(root);
    } catch (e) { toast('Gagal menyimpan: ' + e.message); }
  };

  close = sheet(c ? 'Ubah mata kuliah' : 'Tambah mata kuliah', h('div', {},
    field('Nama mata kuliah *', name), field('Kode (opsional)', code), field('Jumlah SKS *', sks),
    field('Dosen (opsional)', lec), field('Warna', h('div', { class: 'swatches' }, sws)), field('Catatan (opsional)', note),
    h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => close() }, 'Batal'),
      h('button', { class: 'btn primary', onclick: save }, 'Simpan'))));
}
