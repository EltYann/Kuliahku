// Fungsi bantu tampilan. Teks selalu dimasukkan sebagai teks biasa (aman dari injeksi HTML).
export function h(tag, attrs = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (k === 'class') e.className = v;
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  e.append(...kids.flat().filter(x => x != null && x !== false));
  return e;
}

export function toast(msg) {
  const t = h('div', { class: 'toast', role: 'status' }, msg);
  document.body.append(t);
  setTimeout(() => t.remove(), 2600);
}

export function sheet(title, content) {
  const m = h('div', { class: 'overlay' }, h('div', { class: 'sheet' }, h('h3', {}, title), content));
  document.body.append(m);
  return () => m.remove();
}

export function confirmBox(title, text, okLabel = 'Ya, lanjutkan') {
  return new Promise(res => {
    let close;
    const done = v => { close(); res(v); };
    close = sheet(title, h('div', {}, h('p', {}, text),
      h('div', { class: 'row' },
        h('button', { class: 'btn', onclick: () => done(false) }, 'Batal'),
        h('button', { class: 'btn danger', onclick: () => done(true) }, okLabel))));
  });
}

export const empty = (title, text) => h('div', { class: 'card empty' }, h('h3', {}, title), h('p', { class: 'muted' }, text));
export const field = (label, el) => h('label', { class: 'field' }, h('span', {}, label), el);
