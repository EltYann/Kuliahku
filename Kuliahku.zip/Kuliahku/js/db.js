// Penyimpanan data utama: IndexedDB (tersimpan di HP, tanpa server).
const DB_NAME = 'kuliahku', DB_VER = 1;
export const STORES = ['courses', 'schedules', 'tasks', 'exams', 'notes', 'groups', 'attendance'];
let dbPromise;

export function openDB() {
  if (!dbPromise) dbPromise = new Promise((res, rej) => {
    if (!('indexedDB' in window)) return rej(new Error('Browser ini tidak mendukung penyimpanan lokal.'));
    const r = indexedDB.open(DB_NAME, DB_VER);
    r.onupgradeneeded = () => {
      for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath: 'id' });
    };
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  return dbPromise;
}

async function run(store, mode, fn) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    t.oncomplete = () => res(req.result);
    t.onerror = t.onabort = () => rej(t.error);
  });
}

export const getAll = s => run(s, 'readonly', o => o.getAll());
export const getOne = (s, id) => run(s, 'readonly', o => o.get(id));
export const remove = (s, id) => run(s, 'readwrite', o => o.delete(id));
export async function put(s, item) {
  item.id = item.id || crypto.randomUUID();
  item.updatedAt = Date.now();
  await run(s, 'readwrite', o => o.put(item));
  return item;
}

export async function exportAll() {
  const data = { app: 'KuliahKu', version: 1, exportedAt: new Date().toISOString(), stores: {} };
  for (const s of STORES) data.stores[s] = await getAll(s);
  return data;
}

// Impor dengan validasi. Semua-atau-tidak-sama-sekali: jika gagal, data lama tetap aman.
export async function importAll(json) {
  if (!json || json.app !== 'KuliahKu' || typeof json.stores !== 'object' || !json.stores)
    throw new Error('Berkas ini bukan cadangan KuliahKu.');
  for (const s of STORES) {
    const list = json.stores[s];
    if (list !== undefined && (!Array.isArray(list) || list.some(i => !i || typeof i.id !== 'string')))
      throw new Error('Data "' + s + '" di berkas tidak valid.');
  }
  const db = await openDB();
  return new Promise((res, rej) => {
    const t = db.transaction(STORES, 'readwrite');
    for (const s of STORES) { const o = t.objectStore(s); o.clear(); (json.stores[s] || []).forEach(i => o.put(i)); }
    t.oncomplete = res; t.onerror = t.onabort = () => rej(t.error);
  });
}

export async function resetAll() {
  const db = await openDB();
  return new Promise((res, rej) => {
    const t = db.transaction(STORES, 'readwrite');
    STORES.forEach(s => t.objectStore(s).clear());
    t.oncomplete = res; t.onerror = t.onabort = () => rej(t.error);
  });
}
