// Pintu masuk aplikasi: navigasi bawah, halaman Beranda, dan pendaftaran Service Worker.
import { h, empty } from './ui.js';
import { getAll } from './db.js';
import { getPrefs, setPrefs, applyTheme, renderSettings } from './settings.js';
import { renderCourses } from './courses.js';

const view = document.getElementById('view');
const nav = document.getElementById('nav');
const routes = { '#/': renderHome, '#/courses': renderCourses, '#/settings': renderSettings };
const tabs = [['#/', '🏠', 'Beranda'], ['#/courses', '📚', 'Kuliah'], ['#/settings', '⚙️', 'Pengaturan']];

async function renderHome(root) {
  const p = getPrefs(), courses = await getAll('courses');
  const jam = new Date().getHours();
  const sapa = jam < 11 ? 'Selamat pagi' : jam < 15 ? 'Selamat siang' : jam < 18 ? 'Selamat sore' : 'Selamat malam';
  const tgl = new Date().toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const nm = h('input', { placeholder: 'Nama panggilan (opsional)', maxlength: 30 });
  const sm = h('input', { placeholder: 'Semester (opsional)', maxlength: 10 });
  const welcome = h('div', { class: 'card' }, h('h3', {}, 'Selamat datang di KuliahKu'),
    h('p', { class: 'muted' }, 'Tanpa akun, tanpa login. Semua data tersimpan di HP ini. Boleh dilewati.'),
    nm, h('div', { style: 'height:10px' }), sm,
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => { setPrefs({ onboarded: true }); renderHome(root); } }, 'Lewati'),
      h('button', { class: 'btn primary', onclick: () => { setPrefs({ name: nm.value.trim(), semester: sm.value.trim(), onboarded: true }); renderHome(root); } }, 'Simpan')));

  root.replaceChildren(
    h('h2', {}, `${sapa}${p.name ? ', ' + p.name : ''}!`),
    h('p', { class: 'muted' }, tgl + (p.semester ? ` • Semester ${p.semester}` : '')),
    !p.onboarded && welcome,
    h('div', { class: 'stats' },
      h('div', { class: 'card' }, h('b', {}, courses.length), 'Mata kuliah'),
      h('div', { class: 'card' }, h('b', {}, courses.reduce((a, c) => a + c.sks, 0)), 'Total SKS')),
    courses.length ? null : empty('Mulai dari mata kuliah', 'Tambahkan mata kuliah semestermu agar jadwal dan tugas bisa dikaitkan nanti.'),
    h('a', { class: 'btn primary', href: '#/courses', style: 'width:100%' }, courses.length ? 'Kelola mata kuliah' : 'Tambah mata kuliah'),
    h('div', { class: 'card' }, h('h3', {}, 'Segera hadir'),
      h('p', { class: 'muted' }, 'Jadwal, tugas, kalkulator nilai, ujian, catatan, tugas kelompok, dan kehadiran akan ditambahkan di fase berikutnya.')));
}

async function go() {
  const hash = routes[location.hash] ? location.hash : '#/';
  nav.replaceChildren(...tabs.map(([r, ic, lb]) => h('a', { href: r, class: r === hash ? 'on' : '', 'aria-current': r === hash ? 'page' : null }, h('b', {}, ic), lb)));
  try { await routes[hash](view); }
  catch (e) { view.replaceChildren(h('div', { class: 'card' }, h('h3', {}, 'Penyimpanan lokal bermasalah'), h('p', {}, e.message), h('p', { class: 'muted' }, 'Coba muat ulang halaman, atau nonaktifkan mode penyamaran/privat di browser.'))); }
  scrollTo(0, 0);
}

applyTheme();
addEventListener('hashchange', go);
go();
navigator.storage?.persist?.(); // minta browser agar tidak menghapus data otomatis
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
